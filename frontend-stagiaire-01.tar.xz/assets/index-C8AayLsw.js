(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))n(a);new MutationObserver(a=>{for(const i of a)if(i.type==="childList")for(const g of i.addedNodes)g.tagName==="LINK"&&g.rel==="modulepreload"&&n(g)}).observe(document,{childList:!0,subtree:!0});function s(a){const i={};return a.integrity&&(i.integrity=a.integrity),a.referrerPolicy&&(i.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?i.credentials="include":a.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function n(a){if(a.ep)return;a.ep=!0;const i=s(a);fetch(a.href,i)}})();const p=c`
  <defs>
    <linearGradient id="gradient-primary" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#3b82f6"/>
      <stop offset="100%" style="stop-color:#8b5cf6"/>
    </linearGradient>
    <linearGradient id="gradient-hourglass" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#f59e0b"/>
      <stop offset="100%" style="stop-color:#ef4444"/>
    </linearGradient>
    <linearGradient id="gradient-success" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#22c55e"/>
      <stop offset="100%" style="stop-color:#10b981"/>
    </linearGradient>
    <linearGradient id="gradient-danger" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#ef4444"/>
      <stop offset="100%" style="stop-color:#dc2626"/>
    </linearGradient>
  </defs>
`,d={vote:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="url(#gradient-primary)" class="bi bi-collection icon-gradient" viewBox="0 0 16 16"${e}>
      ${p}
      <path d="M2.5 3.5a.5.5 0 0 1 0-1h11a.5.5 0 0 1 0 1zm2-2a.5.5 0 0 1 0-1h7a.5.5 0 0 1 0 1zM0 13a1.5 1.5 0 0 0 1.5 1.5h13A1.5 1.5 0 0 0 16 13V6a1.5 1.5 0 0 0-1.5-1.5h-13A1.5 1.5 0 0 0 0 6zm1.5.5A.5.5 0 0 1 1 13V6a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5z"/>
    </svg>`,timer:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-stopwatch" viewBox="0 0 16 16"${e}>
      <path d="M8.5 5.6a.5.5 0 1 0-1 0v2.9h-3a.5.5 0 0 0 0 1H8a.5.5 0 0 0 .5-.5z"/>
      <path d="M6.5 1A.5.5 0 0 1 7 .5h2a.5.5 0 0 1 0 1v.57c1.36.196 2.594.78 3.584 1.64l.012-.013.354-.354-.354-.353a.5.5 0 0 1 .707-.708l1.414 1.415a.5.5 0 1 1-.707.707l-.353-.354-.354.354-.013.012A7 7 0 1 1 7 2.071V1.5a.5.5 0 0 1-.5-.5M8 3a6 6 0 1 0 .001 12A6 6 0 0 0 8 3"/>
    </svg>`,chart:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bar-chart-fill" viewBox="0 0 16 16"${e}>
      <path d="M1 11a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1zm5-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1z"/>
    </svg>`,rocket:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-rocket-takeoff" viewBox="0 0 16 16"${e}>
      <path d="M9.752 6.193c.599.6 1.73.437 2.528-.362s.96-1.932.362-2.531c-.599-.6-1.73-.438-2.528.361-.798.8-.96 1.933-.362 2.532"/>
      <path d="M15.811 3.312c-.363 1.534-1.334 3.626-3.64 6.218l-.24 2.408a2.56 2.56 0 0 1-.732 1.526L8.817 15.85a.51.51 0 0 1-.867-.434l.27-1.899c.04-.28-.013-.593-.131-.956a9 9 0 0 0-.249-.657l-.082-.202c-.815-.197-1.578-.662-2.191-1.277-.614-.615-1.079-1.379-1.275-2.195l-.203-.083a10 10 0 0 0-.655-.248c-.363-.119-.675-.172-.955-.132l-1.896.27A.51.51 0 0 1 .15 7.17l2.382-2.386c.41-.41.947-.67 1.524-.734h.006l2.4-.238C9.005 1.55 11.087.582 12.623.208c.89-.217 1.59-.232 2.08-.188.244.023.435.06.57.093q.1.026.16.045c.184.06.279.13.351.295l.029.073a3.5 3.5 0 0 1 .157.721c.055.485.051 1.178-.159 2.065m-4.828 7.475.04-.04-.107 1.081a1.54 1.54 0 0 1-.44.913l-1.298 1.3.054-.38c.072-.506-.034-.993-.172-1.418a9 9 0 0 0-.164-.45c.738-.065 1.462-.38 2.087-1.006M5.205 5c-.625.626-.94 1.351-1.004 2.09a9 9 0 0 0-.45-.164c-.424-.138-.91-.244-1.416-.172l-.38.054 1.3-1.3c.245-.246.566-.401.91-.44l1.08-.107zm9.406-3.961c-.38-.034-.967-.027-1.746.163-1.558.38-3.917 1.496-6.937 4.521-.62.62-.799 1.34-.687 2.051.107.676.483 1.362 1.048 1.928.564.565 1.25.941 1.924 1.049.71.112 1.429-.067 2.048-.688 3.079-3.083 4.192-5.444 4.556-6.987.183-.771.18-1.345.138-1.713a3 3 0 0 0-.045-.283 3 3 0 0 0-.3-.041Z"/>
      <path d="M7.009 12.139a7.6 7.6 0 0 1-1.804-1.352A7.6 7.6 0 0 1 3.794 8.86c-1.102.992-1.965 5.054-1.839 5.18.125.126 3.936-.896 5.054-1.902Z"/>
    </svg>`,stop:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="url(#gradient-danger)" class="bi bi-stop-circle icon-gradient-danger" viewBox="0 0 16 16"${e}>
      ${p}
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M5 6.5A1.5 1.5 0 0 1 6.5 5h3A1.5 1.5 0 0 1 11 6.5v3A1.5 1.5 0 0 1 9.5 11h-3A1.5 1.5 0 0 1 5 9.5z"/>
    </svg>`,settings:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-gear" viewBox="0 0 16 16"${e}>
      <path d="M8 4.754a3.246 3.246 0 1 0 0 6.492 3.246 3.246 0 0 0 0-6.492M5.754 8a2.246 2.246 0 1 1 4.492 0 2.246 2.246 0 0 1-4.492 0"/>
      <path d="M9.796 1.343c-.527-1.79-3.065-1.79-3.592 0l-.094.319a.873.873 0 0 1-1.255.52l-.292-.16c-1.64-.892-3.433.902-2.54 2.541l.159.292a.873.873 0 0 1-.52 1.255l-.319.094c-1.79.527-1.79 3.065 0 3.592l.319.094a.873.873 0 0 1 .52 1.255l-.16.292c-.892 1.64.901 3.434 2.541 2.54l.292-.159a.873.873 0 0 1 1.255.52l.094.319c.527 1.79 3.065 1.79 3.592 0l.094-.319a.873.873 0 0 1 1.255-.52l.292.16c1.64.893 3.434-.902 2.54-2.541l-.159-.292a.873.873 0 0 1 .52-1.255l.319-.094c1.79-.527 1.79-3.065 0-3.592l-.319-.094a.873.873 0 0 1-.52-1.255l.16-.292c.893-1.64-.902-3.433-2.541-2.54l-.292.159a.873.873 0 0 1-1.255-.52zm-2.633.283c.246-.835 1.428-.835 1.674 0l.094.319a1.873 1.873 0 0 0 2.693 1.115l.291-.16c.764-.415 1.6.42 1.184 1.185l-.159.292a1.873 1.873 0 0 0 1.116 2.692l.318.094c.835.246.835 1.428 0 1.674l-.319.094a1.873 1.873 0 0 0-1.115 2.693l.16.291c.415.764-.42 1.6-1.185 1.184l-.291-.159a1.873 1.873 0 0 0-2.693 1.116l-.094.318c-.246.835-1.428.835-1.674 0l-.094-.319a1.873 1.873 0 0 0-2.692-1.115l-.292.16c-.764.415-1.6-.42-1.184-1.185l.159-.291A1.873 1.873 0 0 0 1.945 8.93l-.319-.094c-.835-.246-.835-1.428 0-1.674l.319-.094A1.873 1.873 0 0 0 3.06 4.377l-.16-.292c-.415-.764.42-1.6 1.185-1.184l.292.159a1.873 1.873 0 0 0 2.692-1.115z"/>
    </svg>`,refresh:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-clockwise" viewBox="0 0 16 16"${e}>
      <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2z"/>
      <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466"/>
    </svg>`,users:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-people" viewBox="0 0 16 16"${e}>
      <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1zm-7.978-1L7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002-.014.002zM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4m3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0M6.936 9.28a6 6 0 0 0-1.23-.247A7 7 0 0 0 5 9c-4 0-5 3-5 4q0 1 1 1h4.216A2.24 2.24 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816M4.92 10A5.5 5.5 0 0 0 4 13H1c0-.26.164-1.03.76-1.724.545-.636 1.492-1.256 3.16-1.275ZM1.5 5.5a3 3 0 1 1 6 0 3 3 0 0 1-6 0m3-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4"/>
    </svg>`,chevronDown:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-down" viewBox="0 0 16 16"${e}>
      <path d="M3.204 5h9.592L8 10.481zm-.753.659 4.796 5.48a1 1 0 0 0 1.506 0l4.796-5.48c.566-.647.106-1.659-.753-1.659H3.204a1 1 0 0 0-.753 1.659"/>
    </svg>`,check:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="url(#gradient-success)" class="bi bi-check-lg icon-gradient-success" viewBox="0 0 16 16"${e}>
      ${p}
      <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425z"/>
    </svg>`,checkCircle:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16"${e}>
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="m10.97 4.97-.02.022-3.473 4.425-2.093-2.094a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05"/>
    </svg>`,hourglass:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="url(#gradient-hourglass)" class="bi bi-hourglass icon-gradient-hourglass" viewBox="0 0 16 16"${e}>
      ${p}
      <path d="M2 1.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-1v1a4.5 4.5 0 0 1-2.557 4.06c-.29.139-.443.377-.443.59v.7c0 .213.154.451.443.59A4.5 4.5 0 0 1 12.5 13v1h1a.5.5 0 0 1 0 1h-11a.5.5 0 1 1 0-1h1v-1a4.5 4.5 0 0 1 2.557-4.06c.29-.139.443-.377.443-.59v-.7c0-.213-.154-.451-.443-.59A4.5 4.5 0 0 1 3.5 3V2h-1a.5.5 0 0 1-.5-.5m2.5.5v1a3.5 3.5 0 0 0 1.989 3.158c.533.256 1.011.791 1.011 1.491v.702c0 .7-.478 1.235-1.011 1.491A3.5 3.5 0 0 0 4.5 13v1h7v-1a3.5 3.5 0 0 0-1.989-3.158C8.978 9.586 8.5 9.052 8.5 8.351v-.702c0-.7.478-1.235 1.011-1.491A3.5 3.5 0 0 0 11.5 3V2z"/>
    </svg>`,pencil:(e="")=>c`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16"${e}>
      <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
    </svg>`};function c(e,...o){return e.reduce((s,n,a)=>s+n+(o[a]||""),"")}const m={author:"Robin DUBREUIL",commitHash:"407e4a5",commitDate:"2026-01-08",fullHash:"407e4a586c172cb75f9fc9ed6663abad733e59d4"},w=[{id:"rouge",name:"Rouge",color:"#ef4444"},{id:"vert",name:"Vert",color:"#22c55e"},{id:"bleu",name:"Bleu",color:"#3b82f6"},{id:"jaune",name:"Jaune",color:"#eab308"},{id:"orange",name:"Orange",color:"#f97316"},{id:"violet",name:"Violet",color:"#a855f7"},{id:"rose",name:"Rose",color:"#ec4899"},{id:"gris",name:"Gris",color:"#6b7280"}],y=`${location.protocol==="https:"?"wss:":"ws:"}//${location.host}/ws`,r={JOINING:"joining",WAITING:"waiting",VOTING:"voting",VOTED:"voted",CLOSED:"closed"},t={appState:r.JOINING,sessionCode:"",sessionId:null,connected:!1,availableColors:[],multipleChoice:!1,selectedColors:new Set,hasVoted:!1,stagiaireId:null,prenom:"",prenomEdit:!1};let C=null,u=null;function I(){C=document.getElementById("app");let e=localStorage.getItem("vote_stagiaire_id");e||(e="stagiaire_"+Math.random().toString(36).substr(2,9),localStorage.setItem("vote_stagiaire_id",e)),t.stagiaireId=e;const o=localStorage.getItem("vote_stagiaire_prenom");o&&(t.prenom=o);const s=localStorage.getItem("vote_session_code");s?(t.sessionCode=s,t.prenom?f(s):l()):l()}function f(e){h(!1),u=new WebSocket(y),u.onopen=()=>{console.log("WebSocket connecté"),h(!0),b({type:"stagiaire_join",sessionCode:e,stagiaireId:t.stagiaireId,name:t.prenom})},u.onmessage=o=>{try{const s=JSON.parse(o.data);x(s)}catch(s){console.error("Erreur parsing message:",s)}},u.onclose=()=>{console.log("WebSocket déconnecté"),h(!1),setTimeout(()=>{t.sessionCode&&f(t.sessionCode)},2e3)},u.onerror=o=>{console.error("WebSocket error:",o)}}function b(e){u&&u.readyState===WebSocket.OPEN&&u.send(JSON.stringify(e))}function x(e){switch(e.type){case"session_joined":t.sessionId=e.sessionId,t.sessionCode=e.sessionCode,t.appState=r.WAITING,localStorage.setItem("vote_session_code",e.sessionCode),l();break;case"join_error":v("Code de session invalide ou session non trouvée"),t.appState=r.JOINING,t.sessionCode="",localStorage.removeItem("vote_session_code"),l();break;case"vote_started":t.availableColors=e.colors||[],t.multipleChoice=e.multipleChoice||!1,t.selectedColors.clear(),t.hasVoted=!1,t.appState=r.VOTING,l();break;case"vote_accepted":t.hasVoted=!0,t.appState=r.VOTED,l();break;case"vote_closed":t.appState=r.CLOSED,l();break;case"vote_reset":t.appState=r.WAITING,t.selectedColors.clear(),t.hasVoted=!1,l();break;case"config_updated":e.colors&&(t.availableColors=e.colors),e.multipleChoice!==void 0&&(t.multipleChoice=e.multipleChoice),t.appState===r.VOTING&&(t.selectedColors.clear(),l());break;case"name_updated":t.prenomEdit=!1,l();break}}function h(e){t.connected=e;const o=document.querySelector(".connection-status");if(o&&o.remove(),t.appState===r.JOINING)return;const s=document.createElement("div");s.className=`connection-status ${e?"connected":"disconnected"}`,s.innerHTML=`
    <span class="dot"></span>
    ${e?"":"Reconnexion..."}
  `,document.body.appendChild(s)}function v(e){const o=document.querySelector(".error-message");o&&(o.textContent=e,setTimeout(()=>{o.textContent=""},3e3))}function l(){C.innerHTML=`
    <div class="container">
      ${t.appState===r.JOINING?L():""}
      ${t.prenomEdit?M():""}
      ${t.appState===r.WAITING&&!t.prenomEdit?S():""}
      ${t.appState===r.VOTING&&!t.prenomEdit?A():""}
      ${t.appState===r.VOTED&&!t.prenomEdit?N():""}
      ${t.appState===r.CLOSED&&!t.prenomEdit?B():""}
    </div>
    ${E()}
  `,z(),h(t.connected)}function E(){return`
    <footer class="footer">
      <span class="footer-author">${m.author}</span>
      <span class="footer-separator">•</span>
      <a href="https://opensource.org/licenses/MIT" target="_blank" class="footer-link">Licence MIT</a>
      <span class="footer-separator">•</span>
      <span class="footer-version" title="${m.fullHash}">${m.commitHash}</span>
      <span class="footer-date">${m.commitDate}</span>
    </footer>
  `}function L(){return`
    <div class="card">
      <h2 class="card-title">${d.vote(' class="icon icon-md"')} Vote Coloré</h2>
      <form class="join-form" id="joinForm">
        <div class="input-group">
          <label for="prenom">Votre prénom</label>
          <input
            type="text"
            id="prenom"
            class="session-input"
            placeholder="Ex: Marie"
            value="${t.prenom}"
            autocomplete="name"
            autocapitalize="words"
            required
          />
        </div>
        <div class="input-group">
          <label for="sessionCode">Code de session</label>
          <input
            type="text"
            id="sessionCode"
            class="session-input"
            placeholder="0000"
            maxlength="4"
            pattern="[0-9]{4}"
            inputmode="numeric"
            value="${t.sessionCode}"
            autocomplete="off"
          />
        </div>
        <div class="error-message"></div>
        <button type="submit" class="btn btn-primary btn-large">
          Rejoindre
        </button>
      </form>
    </div>
  `}function S(){return`
    <header class="header">
      <h1>${d.vote(' class="icon icon-md"')} Vote Coloré</h1>
      <div class="session-code-display valid">
        ${d.check(' class="icon icon-sm text-success"')} ${t.sessionCode}
      </div>
    </header>
    <div class="card">
      <div class="waiting-state">
        <div class="waiting-icon">${d.hourglass(' class="icon icon-xl"')}</div>
        <div class="waiting-text">En attente du prochain vote...</div>
        <div class="waiting-name">Bonjour, <strong>${T(t.prenom)}</strong> !</div>
        <button type="button" class="btn btn-secondary btn-small" id="editNameBtn">
          ${d.pencil(' class="icon icon-sm"')} Modifier mon nom
        </button>
      </div>
    </div>
  `}function M(){return`
    <div class="card edit-name-modal">
      <h2 class="card-title">Modifier mon nom</h2>
      <form class="join-form" id="editNameForm">
        <div class="input-group">
          <label for="editPrenom">Ton prénom</label>
          <input
            type="text"
            id="editPrenom"
            class="session-input"
            placeholder="Ex: Marie"
            value="${t.prenom}"
            autocomplete="name"
            autocapitalize="words"
            required
            autofocus
          />
        </div>
        <div class="button-row">
          <button type="button" class="btn btn-secondary" id="cancelEditName">Annuler</button>
          <button type="submit" class="btn btn-primary">Enregistrer</button>
        </div>
      </form>
    </div>
  `}function A(){const e=w.filter(o=>t.availableColors.includes(o.id));return`
    <header class="header">
      <h1>${d.vote(' class="icon icon-md"')} Vote Coloré</h1>
      <div class="session-code-display valid">
        ${d.check(' class="icon icon-sm text-success"')} ${t.sessionCode}
      </div>
    </header>
    <div class="card">
      <h2 class="card-title">Votez maintenant !</h2>
      <p class="vote-instruction ${t.multipleChoice?"multiple-choice":"single-choice"}">
        ${t.multipleChoice?"Vous pouvez choisir plusieurs couleurs":"Choisissez une seule couleur"}
      </p>

      ${t.multipleChoice?k(e):V(e)}
    </div>
  `}function V(e){return`
    <div class="vote-grid">
      ${e.map(o=>`
        <button
          type="button"
          class="vote-button bg-${o.id} ${t.selectedColors.has(o.id)?"selected":""}"
          data-color="${o.id}"
          aria-pressed="${t.selectedColors.has(o.id)}"
        >
          ${o.name}
        </button>
      `).join("")}
    </div>
  `}function k(e){return`
    <div class="vote-grid">
      ${e.map(o=>`
        <input
          type="checkbox"
          id="color-${o.id}"
          class="vote-checkbox"
          value="${o.id}"
          ${t.selectedColors.has(o.id)?"checked":""}
        />
        <label
          for="color-${o.id}"
          class="vote-checkbox-label bg-${o.id} ${t.selectedColors.has(o.id)?"selected":""}"
        >
          ${o.name}
          <span class="check-indicator"></span>
        </label>
      `).join("")}
    </div>
    <button type="button" class="btn btn-success btn-large" id="submitVote" ${t.selectedColors.size===0?"disabled":""}>
      Valider mon vote
    </button>
  `}function N(){const e=Array.from(t.selectedColors).map(o=>w.find(n=>n.id===o)?.name||o).join(" + ");return`
    <header class="header">
      <h1>${d.vote(' class="icon icon-md"')} Vote Coloré</h1>
      <div class="session-code-display valid">
        ${d.check(' class="icon icon-sm text-success"')} ${t.sessionCode}
      </div>
    </header>
    <div class="card">
      <div class="voted-state">
        <div class="voted-icon">${d.check(' class="icon icon-xl"')}</div>
        <div class="voted-title">Vote enregistré !</div>
        <div class="voted-subtitle">${e}</div>
      </div>
    </div>
  `}function B(){return`
    <header class="header">
      <h1>${d.vote(' class="icon icon-md"')} Vote Coloré</h1>
      <div class="session-code-display valid">
        ${d.check(' class="icon icon-sm text-success"')} ${t.sessionCode}
      </div>
    </header>
    <div class="card">
      <div class="vote-closed-state">
        <div class="closed-icon">${d.stop(' class="icon icon-xl"')}</div>
        <div class="waiting-text">Le vote est terminé</div>
      </div>
    </div>
  `}function z(){const e=document.getElementById("joinForm");e&&e.addEventListener("submit",_);const o=document.getElementById("editNameForm");o&&o.addEventListener("submit",O);const s=document.getElementById("editNameBtn");s&&s.addEventListener("click",()=>{t.prenomEdit=!0,l()});const n=document.getElementById("cancelEditName");n&&n.addEventListener("click",()=>{t.prenomEdit=!1,l()}),document.querySelectorAll(".vote-button").forEach(i=>{i.addEventListener("click",G)}),document.querySelectorAll(".vote-checkbox").forEach(i=>{i.addEventListener("change",H)});const a=document.getElementById("submitVote");a&&a.addEventListener("click",j)}function T(e){const o=document.createElement("div");return o.textContent=e,o.innerHTML}function _(e){e.preventDefault();const o=document.getElementById("prenom"),s=document.getElementById("sessionCode"),n=o.value.trim(),a=s.value.trim();if(n.length<2){o.classList.add("error"),v("Le prénom doit contenir au moins 2 caractères");return}if(!/^\d{4}$/.test(a)){s.classList.add("error"),v("Le code doit contenir 4 chiffres");return}o.classList.remove("error"),s.classList.remove("error"),t.prenom=n,t.sessionCode=a,localStorage.setItem("vote_stagiaire_prenom",n),f(a)}function O(e){e.preventDefault();const o=document.getElementById("editPrenom"),s=o.value.trim();if(s.length<2){o.classList.add("error"),v("Le prénom doit contenir au moins 2 caractères");return}o.classList.remove("error"),t.prenom=s,localStorage.setItem("vote_stagiaire_prenom",s),b({type:"update_name",name:s}),t.prenomEdit=!1,l()}function G(e){const o=e.target.dataset.color;t.selectedColors.clear(),t.selectedColors.add(o),$()}function H(e){const o=e.target.value;document.querySelector(`label[for="color-${o}"]`),e.target.checked?t.selectedColors.add(o):t.selectedColors.delete(o),document.querySelectorAll(".vote-checkbox-label").forEach(a=>{const i=document.getElementById(a.htmlFor);i&&i.checked?a.classList.add("selected"):a.classList.remove("selected")});const n=document.getElementById("submitVote");n&&(n.disabled=t.selectedColors.size===0)}function j(){t.selectedColors.size>0&&$()}function $(){b({type:"vote",sessionId:t.sessionId,stagiaireId:t.stagiaireId,colors:Array.from(t.selectedColors)})}I();
