(function(){const s=document.createElement("link").relList;if(s&&s.supports&&s.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))a(n);new MutationObserver(n=>{for(const i of n)if(i.type==="childList")for(const c of i.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&a(c)}).observe(document,{childList:!0,subtree:!0});function o(n){const i={};return n.integrity&&(i.integrity=n.integrity),n.referrerPolicy&&(i.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?i.credentials="include":n.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function a(n){if(n.ep)return;n.ep=!0;const i=o(n);fetch(n.href,i)}})();const g=r`
  <defs>
    <linearGradient id="gradient-primary" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#3b82f6"/>
      <stop offset="100%" style="stop-color:#8b5cf6"/>
    </linearGradient>
    <linearGradient id="gradient-hourglass" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#f59e0b"/>
      <stop offset="100%" style="stop-color:#ef4444"/>
    </linearGradient>
    <linearGradient id="gradient-success" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#22c55e"/>
      <stop offset="100%" style="stop-color:#10b981"/>
    </linearGradient>
    <linearGradient id="gradient-danger" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#ef4444"/>
      <stop offset="100%" style="stop-color:#dc2626"/>
    </linearGradient>
  </defs>
`,l={vote:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="url(#gradient-primary)" class="bi bi-collection icon-gradient" viewBox="0 0 16 16"${e}>
      ${g}
      <path d="M2.5 3.5a.5.5 0 0 1 0-1h11a.5.5 0 0 1 0 1zm2-2a.5.5 0 0 1 0-1h7a.5.5 0 0 1 0 1zM0 13a1.5 1.5 0 0 0 1.5 1.5h13A1.5 1.5 0 0 0 16 13V6a1.5 1.5 0 0 0-1.5-1.5h-13A1.5 1.5 0 0 0 0 6zm1.5.5A.5.5 0 0 1 1 13V6a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5z"/>
    </svg>`,timer:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-stopwatch" viewBox="0 0 16 16"${e}>
      <path d="M8.5 5.6a.5.5 0 1 0-1 0v2.9h-3a.5.5 0 0 0 0 1H8a.5.5 0 0 0 .5-.5z"/>
      <path d="M6.5 1A.5.5 0 0 1 7 .5h2a.5.5 0 0 1 0 1v.57c1.36.196 2.594.78 3.584 1.64l.012-.013.354-.354-.354-.353a.5.5 0 0 1 .707-.708l1.414 1.415a.5.5 0 1 1-.707.707l-.353-.354-.354.354-.013.012A7 7 0 1 1 7 2.071V1.5a.5.5 0 0 1-.5-.5M8 3a6 6 0 1 0 .001 12A6 6 0 0 0 8 3"/>
    </svg>`,chart:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bar-chart-fill" viewBox="0 0 16 16"${e}>
      <path d="M1 11a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1zm5-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1z"/>
    </svg>`,rocket:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-rocket-takeoff" viewBox="0 0 16 16"${e}>
      <path d="M9.752 6.193c.599.6 1.73.437 2.528-.362s.96-1.932.362-2.531c-.599-.6-1.73-.438-2.528.361-.798.8-.96 1.933-.362 2.532"/>
      <path d="M15.811 3.312c-.363 1.534-1.334 3.626-3.64 6.218l-.24 2.408a2.56 2.56 0 0 1-.732 1.526L8.817 15.85a.51.51 0 0 1-.867-.434l.27-1.899c.04-.28-.013-.593-.131-.956a9 9 0 0 0-.249-.657l-.082-.202c-.815-.197-1.578-.662-2.191-1.277-.614-.615-1.079-1.379-1.275-2.195l-.203-.083a10 10 0 0 0-.655-.248c-.363-.119-.675-.172-.955-.132l-1.896.27A.51.51 0 0 1 .15 7.17l2.382-2.386c.41-.41.947-.67 1.524-.734h.006l2.4-.238C9.005 1.55 11.087.582 12.623.208c.89-.217 1.59-.232 2.08-.188.244.023.435.06.57.093q.1.026.16.045c.184.06.279.13.351.295l.029.073a3.5 3.5 0 0 1 .157.721c.055.485.051 1.178-.159 2.065m-4.828 7.475.04-.04-.107 1.081a1.54 1.54 0 0 1-.44.913l-1.298 1.3.054-.38c.072-.506-.034-.993-.172-1.418a9 9 0 0 0-.164-.45c.738-.065 1.462-.38 2.087-1.006M5.205 5c-.625.626-.94 1.351-1.004 2.09a9 9 0 0 0-.45-.164c-.424-.138-.91-.244-1.416-.172l-.38.054 1.3-1.3c.245-.246.566-.401.91-.44l1.08-.107zm9.406-3.961c-.38-.034-.967-.027-1.746.163-1.558.38-3.917 1.496-6.937 4.521-.62.62-.799 1.34-.687 2.051.107.676.483 1.362 1.048 1.928.564.565 1.25.941 1.924 1.049.71.112 1.429-.067 2.048-.688 3.079-3.083 4.192-5.444 4.556-6.987.183-.771.18-1.345.138-1.713a3 3 0 0 0-.045-.283 3 3 0 0 0-.3-.041Z"/>
      <path d="M7.009 12.139a7.6 7.6 0 0 1-1.804-1.352A7.6 7.6 0 0 1 3.794 8.86c-1.102.992-1.965 5.054-1.839 5.18.125.126 3.936-.896 5.054-1.902Z"/>
    </svg>`,stop:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="url(#gradient-danger)" class="bi bi-stop-circle icon-gradient-danger" viewBox="0 0 16 16"${e}>
      ${g}
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M5 6.5A1.5 1.5 0 0 1 6.5 5h3A1.5 1.5 0 0 1 11 6.5v3A1.5 1.5 0 0 1 9.5 11h-3A1.5 1.5 0 0 1 5 9.5z"/>
    </svg>`,settings:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-gear" viewBox="0 0 16 16"${e}>
      <path d="M8 4.754a3.246 3.246 0 1 0 0 6.492 3.246 3.246 0 0 0 0-6.492M5.754 8a2.246 2.246 0 1 1 4.492 0 2.246 2.246 0 0 1-4.492 0"/>
      <path d="M9.796 1.343c-.527-1.79-3.065-1.79-3.592 0l-.094.319a.873.873 0 0 1-1.255.52l-.292-.16c-1.64-.892-3.433.902-2.54 2.541l.159.292a.873.873 0 0 1-.52 1.255l-.319.094c-1.79.527-1.79 3.065 0 3.592l.319.094a.873.873 0 0 1 .52 1.255l-.16.292c-.892 1.64.901 3.434 2.541 2.54l.292-.159a.873.873 0 0 1 1.255.52l.094.319c.527 1.79 3.065 1.79 3.592 0l.094-.319a.873.873 0 0 1 1.255-.52l.292.16c1.64.893 3.434-.902 2.54-2.541l-.159-.292a.873.873 0 0 1 .52-1.255l.319-.094c1.79-.527 1.79-3.065 0-3.592l-.319-.094a.873.873 0 0 1-.52-1.255l.16-.292c.893-1.64-.902-3.433-2.541-2.54l-.292.159a.873.873 0 0 1-1.255-.52zm-2.633.283c.246-.835 1.428-.835 1.674 0l.094.319a1.873 1.873 0 0 0 2.693 1.115l.291-.16c.764-.415 1.6.42 1.184 1.185l-.159.292a1.873 1.873 0 0 0 1.116 2.692l.318.094c.835.246.835 1.428 0 1.674l-.319.094a1.873 1.873 0 0 0-1.115 2.693l.16.291c.415.764-.42 1.6-1.185 1.184l-.291-.159a1.873 1.873 0 0 0-2.693 1.116l-.094.318c-.246.835-1.428.835-1.674 0l-.094-.319a1.873 1.873 0 0 0-2.692-1.115l-.292.16c-.764.415-1.6-.42-1.184-1.185l.159-.291A1.873 1.873 0 0 0 1.945 8.93l-.319-.094c-.835-.246-.835-1.428 0-1.674l.319-.094A1.873 1.873 0 0 0 3.06 4.377l-.16-.292c-.415-.764.42-1.6 1.185-1.184l.292.159a1.873 1.873 0 0 0 2.692-1.115z"/>
    </svg>`,refresh:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-clockwise" viewBox="0 0 16 16"${e}>
      <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2z"/>
      <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466"/>
    </svg>`,users:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-people" viewBox="0 0 16 16"${e}>
      <path d="M15 14s1 0 1-1-1-4-5-4-5 3-5 4 1 1 1 1zm-7.978-1L7 12.996c.001-.264.167-1.03.76-1.72C8.312 10.629 9.282 10 11 10c1.717 0 2.687.63 3.24 1.276.593.69.758 1.457.76 1.72l-.008.002-.014.002zM11 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4m3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0M6.936 9.28a6 6 0 0 0-1.23-.247A7 7 0 0 0 5 9c-4 0-5 3-5 4q0 1 1 1h4.216A2.24 2.24 0 0 1 5 13c0-1.01.377-2.042 1.09-2.904.243-.294.526-.569.846-.816M4.92 10A5.5 5.5 0 0 0 4 13H1c0-.26.164-1.03.76-1.724.545-.636 1.492-1.256 3.16-1.275ZM1.5 5.5a3 3 0 1 1 6 0 3 3 0 0 1-6 0m3-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4"/>
    </svg>`,chevronDown:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-down" viewBox="0 0 16 16"${e}>
      <path d="M3.204 5h9.592L8 10.481zm-.753.659 4.796 5.48a1 1 0 0 0 1.506 0l4.796-5.48c.566-.647.106-1.659-.753-1.659H3.204a1 1 0 0 0-.753 1.659"/>
    </svg>`,check:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="url(#gradient-success)" class="bi bi-check-lg icon-gradient-success" viewBox="0 0 16 16"${e}>
      ${g}
      <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425z"/>
    </svg>`,checkCircle:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle" viewBox="0 0 16 16"${e}>
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="m10.97 4.97-.02.022-3.473 4.425-2.093-2.094a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05"/>
    </svg>`,hourglass:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="url(#gradient-hourglass)" class="bi bi-hourglass icon-gradient-hourglass" viewBox="0 0 16 16"${e}>
      ${g}
      <path d="M2 1.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-1v1a4.5 4.5 0 0 1-2.557 4.06c-.29.139-.443.377-.443.59v.7c0 .213.154.451.443.59A4.5 4.5 0 0 1 12.5 13v1h1a.5.5 0 0 1 0 1h-11a.5.5 0 1 1 0-1h1v-1a4.5 4.5 0 0 1 2.557-4.06c.29-.139.443-.377.443-.59v-.7c0-.213-.154-.451-.443-.59A4.5 4.5 0 0 1 3.5 3V2h-1a.5.5 0 0 1-.5-.5m2.5.5v1a3.5 3.5 0 0 0 1.989 3.158c.533.256 1.011.791 1.011 1.491v.702c0 .7-.478 1.235-1.011 1.491A3.5 3.5 0 0 0 4.5 13v1h7v-1a3.5 3.5 0 0 0-1.989-3.158C8.978 9.586 8.5 9.052 8.5 8.351v-.702c0-.7.478-1.235 1.011-1.491A3.5 3.5 0 0 0 11.5 3V2z"/>
    </svg>`,pencil:(e="")=>r`<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16"${e}>
      <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
    </svg>`};function r(e,...s){return e.reduce((o,a,n)=>o+a+(s[n]||""),"")}const h={author:"Robin DUBREUIL",commitHash:"407e4a5",commitDate:"2026-01-08",fullHash:"407e4a586c172cb75f9fc9ed6663abad733e59d4"},p=[{id:"rouge",name:"Rouge",color:"#ef4444"},{id:"vert",name:"Vert",color:"#22c55e"},{id:"bleu",name:"Bleu",color:"#3b82f6"},{id:"jaune",name:"Jaune",color:"#eab308"},{id:"orange",name:"Orange",color:"#f97316"},{id:"violet",name:"Violet",color:"#a855f7"},{id:"rose",name:"Rose",color:"#ec4899"},{id:"gris",name:"Gris",color:"#6b7280"}],V=`${location.protocol==="https:"?"wss:":"ws:"}//${location.host}/ws`,t={sessionCode:null,sessionId:null,connected:!1,voteState:"idle",selectedColors:new Set(["rouge","vert","bleu"]),multipleChoice:!1,connectedCount:0,votes:[],stagiaires:[],stagiaireNames:{},voteStartTime:null,timerInterval:null};let L=null,u=null;function T(){L=document.getElementById("app");let e=localStorage.getItem("vote_trainer_id");e||(e="trainer_"+Math.random().toString(36).substr(2,9),localStorage.setItem("vote_trainer_id",e)),t.sessionCode=E(),v(),x()}function E(){return Math.floor(1e3+Math.random()*9e3).toString()}function x(){w(!1),u=new WebSocket(V),u.onopen=()=>{console.log("WebSocket connecté"),w(!0),b({type:"trainer_join",sessionCode:t.sessionCode,trainerId:localStorage.getItem("vote_trainer_id")})},u.onmessage=e=>{try{const s=JSON.parse(e.data);B(s)}catch(s){console.error("Erreur parsing message:",s)}},u.onclose=()=>{console.log("WebSocket déconnecté"),w(!1),setTimeout(x,2e3)},u.onerror=e=>{console.error("WebSocket error:",e)}}function b(e){u&&u.readyState===WebSocket.OPEN&&u.send(JSON.stringify(e))}function B(e){switch(e.type){case"session_created":t.sessionId=e.sessionId,t.sessionCode=e.sessionCode||t.sessionCode,v();break;case"connected_count":t.connectedCount=e.count||0,e.stagiaires&&(t.stagiaires=e.stagiaires,t.stagiaireNames={},e.stagiaires.forEach(a=>{a.name&&(t.stagiaireNames[a.id]=a.name)})),C();break;case"stagiaire_names_updated":e.stagiaires&&(t.stagiaires=e.stagiaires,t.stagiaireNames={},e.stagiaires.forEach(a=>{a.name&&(t.stagiaireNames[a.id]=a.name)}),t.votes.forEach(a=>{t.stagiaireNames[a.stagiaireId]&&(a.stagiaireName=t.stagiaireNames[a.stagiaireId])}),S());break;case"stagiaire_left":t.connectedCount=e.connectedCount||0,C();break;case"vote_started":t.voteState="active",t.voteStartTime=Date.now(),t.votes=[],A(),v();break;case"vote_received":const s=t.votes.findIndex(a=>a.stagiaireId===e.stagiaireId),o={couleurs:e.colors,stagiaireId:e.stagiaireId,stagiaireName:e.stagiaireName||t.stagiaireNames[e.stagiaireId]||""};e.stagiaireName&&(t.stagiaireNames[e.stagiaireId]=e.stagiaireName),s>=0?t.votes[s]=o:t.votes.push(o),S();break;case"vote_closed":t.voteState="closed",m(),v();break;case"vote_reset":t.voteState="idle",t.votes=[],m(),v();break;case"config_updated":e.selectedColors&&(t.selectedColors=new Set(e.selectedColors)),e.multipleChoice!==void 0&&(t.multipleChoice=e.multipleChoice),v();break;case"connected_count":t.connectedCount=e.count,C();break}}function A(){m(),t.timerInterval=setInterval(()=>{const e=document.querySelector(".vote-timer");if(e&&t.voteStartTime){const s=Math.floor((Date.now()-t.voteStartTime)/1e3),o=Math.floor(s/60).toString().padStart(2,"0"),a=(s%60).toString().padStart(2,"0");e.innerHTML=`${l.timer(' class="icon icon-sm"')} ${o}:${a}`}},1e3)}function m(){t.timerInterval&&(clearInterval(t.timerInterval),t.timerInterval=null)}function w(e){t.connected=e;const s=document.querySelector(".connection-status");s&&s.remove();const o=document.createElement("div");o.className=`connection-status ${e?"connected":"disconnected"}`,o.innerHTML=`
    <span class="dot"></span>
    ${e?"Connecté":"Déconnecté..."}
  `,document.body.appendChild(o)}function v(){L.innerHTML=`
    <div class="container">
      ${_()}
      ${t.voteState==="idle"?O():j()}
    </div>
    ${N()}
  `,D()}function N(){return`
    <footer class="footer">
      <span class="footer-author">${h.author}</span>
      <span class="footer-separator">•</span>
      <a href="https://opensource.org/licenses/MIT" target="_blank" class="footer-link">Licence MIT</a>
      <span class="footer-separator">•</span>
      <span class="footer-version" title="${h.fullHash}">${h.commitHash}</span>
      <span class="footer-date">${h.commitDate}</span>
    </footer>
  `}function C(){const e=document.querySelector(".header");e&&(e.innerHTML=z())}function _(){const s=[...t.stagiaires].sort((o,a)=>{const n=(o.name||"Anonyme").toLowerCase(),i=(a.name||"Anonyme").toLowerCase();return n.localeCompare(i)}).map(o=>`
    <div class="stagiaire-popover-item">
      <span class="stagiaire-popover-name">${f(o.name||"Anonyme")}</span>
      <span class="stagiaire-popover-status online"></span>
    </div>
  `).join("");return`
    <header class="header">
      <h1>${l.vote(' class="icon icon-md"')} Vote Coloré - Formateur</h1>
      <div class="session-info">
        ${t.sessionCode?`<span class="session-code">${t.sessionCode}</span>`:""}
        <div class="connected-count popover-trigger">
          <span class="dot"></span>
          <span class="count-text">${t.connectedCount} connecté${t.connectedCount>1?"s":""}</span>
          ${t.connectedCount>0?`<span class="popover-arrow">${l.chevronDown(' class="icon icon-xs"')}</span>`:""}
        </div>
        ${t.connectedCount>0?`
          <div class="stagiaires-popover">
            <div class="popover-header">
              <span class="popover-title">Stagiaires connectés</span>
              <span class="popover-count">${t.connectedCount}</span>
            </div>
            <div class="popover-list">
              ${s}
            </div>
          </div>
        `:""}
      </div>
    </header>
  `}function z(){const s=[...t.stagiaires].sort((o,a)=>{const n=(o.name||"Anonyme").toLowerCase(),i=(a.name||"Anonyme").toLowerCase();return n.localeCompare(i)}).map(o=>`
    <div class="stagiaire-popover-item">
      <span class="stagiaire-popover-name">${f(o.name||"Anonyme")}</span>
      <span class="stagiaire-popover-status online"></span>
    </div>
  `).join("");return`
    <h1>${l.vote(' class="icon icon-md"')} Vote Coloré - Formateur</h1>
    <div class="session-info">
      ${t.sessionCode?`<span class="session-code">${t.sessionCode}</span>`:""}
      <div class="connected-count popover-trigger">
        <span class="dot"></span>
        <span class="count-text">${t.connectedCount} connecté${t.connectedCount>1?"s":""}</span>
        ${t.connectedCount>0?`<span class="popover-arrow">${l.chevronDown(' class="icon icon-xs"')}</span>`:""}
      </div>
      ${t.connectedCount>0?`
        <div class="stagiaires-popover">
          <div class="popover-header">
            <span class="popover-title">Stagiaires connectés</span>
            <span class="popover-count">${t.connectedCount}</span>
          </div>
          <div class="popover-list">
            ${s}
          </div>
        </div>
      `:""}
    </div>
  `}function O(){return`
    <div class="card">
      <h2 class="card-title">Configuration du prochain vote</h2>

      <div class="config-section">
        <div>
          <div class="stats-header">Couleurs disponibles</div>
          <div class="colors-grid">
            ${p.map(e=>`
              <label class="color-checkbox ${t.selectedColors.has(e.id)?"selected":""}">
                <input
                  type="checkbox"
                  value="${e.id}"
                  ${t.selectedColors.has(e.id)?"checked":""}
                />
                <span class="color-swatch" style="background: ${e.color}"></span>
                <span class="color-name">${e.name}</span>
              </label>
            `).join("")}
          </div>
        </div>

        <label class="multiple-choice-toggle">
          <span class="toggle-switch ${t.multipleChoice?"active":""}" data-action="toggle-multiple"></span>
          <span>Choix multiple (autoriser plusieurs couleurs)</span>
        </label>
      </div>

      <div class="button-row">
        <button class="btn btn-primary btn-large" id="startVote" ${t.selectedColors.size<2?"disabled":""}>
          ${l.rocket(' class="icon icon-md"')} Lancer le vote
        </button>
      </div>
    </div>
  `}function j(){const e=p.filter(s=>t.selectedColors.has(s.id));return`
    <div class="card">
      <div class="vote-header">
        <div class="vote-timer">${l.timer(' class="icon icon-sm"')} 00:00</div>
        <div class="vote-stats">${l.chart(' class="icon icon-sm"')} ${t.votes.length} / ${t.connectedCount} votes</div>
      </div>

      <div class="stats-grid stats-grid-3cols">
        <div>
          <div class="stats-header">Par couleur</div>
          <div class="color-bars">
            ${e.map(s=>{const o=H(s.id),a=$(),n=Math.max(...Object.values(a),1),i=o/n*100;return`
                <div class="color-bar-row">
                  <div class="color-bar-label">
                    <span class="color-bar-swatch" style="background: ${s.color}"></span>
                    <span class="color-bar-name">${s.name}</span>
                  </div>
                  <div class="color-bar-track">
                    <span class="color-bar-count">${o}</span>
                    <div class="color-bar-fill ${o===0?"empty":""}" style="width: ${i}%; background: ${s.color}"></div>
                  </div>
                </div>
              `}).join("")}
          </div>
        </div>

        <div>
          <div class="stats-header">Par combinaison</div>
          <div class="combinations-list">
            ${k()}
          </div>
        </div>

        <div>
          <div class="stats-header">Par stagiaire</div>
          <div class="stagiaires-votes-list">
            ${I()}
          </div>
        </div>
      </div>

      <div class="button-row">
        ${t.voteState==="active"?`
          <button class="btn btn-danger" id="closeVote">${l.stop(' class="icon icon-md"')} Fermer le vote</button>
        `:`
          <button class="btn btn-success" id="newVote">${l.refresh(' class="icon icon-md"')} Nouveau vote</button>
        `}
      </div>
    </div>
  `}function k(e){const s=q();if(s.length===0)return`
      <div class="empty-state">
        <div class="empty-icon">${l.chart(' class="icon icon-xl"')}</div>
        <div>Aucun vote pour le moment</div>
      </div>
    `;const o=Math.max(...s.map(a=>a.count));return s.map(a=>{const n=o>0?a.count/o*100:0;return`
      <div class="combo-item">
        <div class="combo-colors">
          ${a.colors.map(i=>`<span class="combo-swatch" style="background: ${p.find(d=>d.id===i)?.color||"#666"}"></span>`).join("")}
        </div>
        <div class="combo-bar">
          <div class="combo-bar-fill" style="width: ${n}%"></div>
        </div>
        <div class="combo-count">${a.count}</div>
      </div>
    `}).join("")}function I(e){return t.votes.length===0?`
      <div class="empty-state">
        <div class="empty-icon">${l.users(' class="icon icon-xl"')}</div>
        <div>Aucun vote pour le moment</div>
      </div>
    `:[...t.votes].sort((o,a)=>{const n=(o.stagiaireName||"Anonyme").toLowerCase(),i=(a.stagiaireName||"Anonyme").toLowerCase();return n.localeCompare(i)}).map(o=>{const a=o.stagiaireName||"Anonyme",n=o.couleurs.map(i=>{const c=p.find(d=>d.id===i);return`<span class="stagiaire-vote-swatch" style="background: ${c?.color||"#666"}" title="${c?.name||i}"></span>`}).join("");return`
      <div class="stagiaire-vote-item">
        <span class="stagiaire-vote-name" title="${f(a)}">${f(a)}</span>
        <div class="stagiaire-vote-colors">${n}</div>
      </div>
    `}).join("")}function f(e){const s=document.createElement("div");return s.textContent=e,s.innerHTML}function q(){const e=new Map;return t.votes.forEach(s=>{const o=s.couleurs.slice().sort().join("+");e.set(o,(e.get(o)||0)+1)}),Array.from(e.entries()).map(([s,o])=>({colors:s?s.split("+"):[],count:o})).sort((s,o)=>o.count-s.count)}function H(e){return $()[e]||0}function $(){const e={};return t.votes.forEach(s=>{s.couleurs.forEach(o=>{e[o]=(e[o]||0)+1})}),e}function S(){const e=document.querySelector(".vote-stats");e&&(e.innerHTML=`${l.chart(' class="icon icon-sm"')} ${t.votes.length} / ${t.connectedCount} votes`);const s=document.querySelector(".color-bars");if(s){const n=p.filter(c=>t.selectedColors.has(c.id)),i=Math.max(...Object.values($()),1);s.innerHTML=n.map(c=>{const d=H(c.id),y=d/i*100;return`
        <div class="color-bar-row">
          <div class="color-bar-label">
            <span class="color-bar-swatch" style="background: ${c.color}"></span>
            <span class="color-bar-name">${c.name}</span>
          </div>
          <div class="color-bar-track">
            <span class="color-bar-count">${d}</span>
            <div class="color-bar-fill ${d===0?"empty":""}" style="width: ${y}%; background: ${c.color}"></div>
          </div>
        </div>
      `}).join("")}const o=document.querySelector(".combinations-list");o&&(p.filter(n=>t.selectedColors.has(n.id)),o.innerHTML=k());const a=document.querySelector(".stagiaires-votes-list");a&&(p.filter(n=>t.selectedColors.has(n.id)),a.innerHTML=I())}function D(){const e=document.querySelector(".popover-trigger");e&&(e.addEventListener("click",i=>{i.target.closest(".stagiaires-popover")||e.classList.toggle("active")}),document.addEventListener("click",i=>{i.target.closest(".session-info")||e.classList.remove("active")})),document.querySelectorAll('.color-checkbox input[type="checkbox"]').forEach(i=>{i.addEventListener("change",c=>{const d=c.target.value;c.target.checked?t.selectedColors.add(d):t.selectedColors.delete(d),c.target.closest(".color-checkbox").classList.toggle("selected",c.target.checked);const M=document.getElementById("startVote");M&&(M.disabled=t.selectedColors.size<2)})});const s=document.querySelector('[data-action="toggle-multiple"]');s&&s.addEventListener("click",()=>{t.multipleChoice=!t.multipleChoice,s.classList.toggle("active",t.multipleChoice)});const o=document.getElementById("startVote");o&&o.addEventListener("click",G);const a=document.getElementById("closeVote");a&&a.addEventListener("click",R);const n=document.getElementById("newVote");n&&n.addEventListener("click",P)}function G(){const e=Array.from(t.selectedColors);b({type:"start_vote",sessionId:t.sessionId,colors:e,multipleChoice:t.multipleChoice}),t.voteState="active",t.voteStartTime=Date.now(),t.votes=[],A(),v()}function R(){b({type:"close_vote",sessionId:t.sessionId}),t.voteState="closed",m(),v()}function P(){b({type:"reset_vote",sessionId:t.sessionId,colors:Array.from(t.selectedColors),multipleChoice:t.multipleChoice}),t.voteState="idle",t.votes=[],m(),v()}T();
